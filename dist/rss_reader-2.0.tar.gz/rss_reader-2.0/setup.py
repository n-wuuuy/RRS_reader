from setuptools import setup

setup(
    name='rss_reader',
    version='2.0',
    py_modules=['rss_reader'],
    python_requires='>=3.10',
    install_requires=[
        'feedparser', 'requests', 'bs4',
    ],
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'rss_reader = rss_reader.rss_reader:run'
        ]
    }
)